# TODO: 
# implement all procedurally
# check arguments are valid
# check functions are valid
# check mathit is valid, use regex
# check all variable names are valid