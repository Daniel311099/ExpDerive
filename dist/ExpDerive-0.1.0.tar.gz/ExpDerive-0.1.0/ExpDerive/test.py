def f(x):
    return x**2